package com.example.atelier6_halima_daoudi;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

public abstract class GPSTracker implements LocationListener {

    private final Context mContext;
    private LocationManager mLocationManager;

    public GPSTracker(Context context) {
        mContext = context;
        mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
    }

    public Location getLocation() {
        try {
            // Vérifiez la permission de localisation
            if (mContext.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                    mContext.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return null;
            }

            // Obtenez la localisation actuelle
            Location locationGPS = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location locationNetwork = mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            // Comparez les deux et prenez la plus récente
            if (locationGPS != null && locationNetwork != null) {
                if (locationGPS.getTime() > locationNetwork.getTime()) {
                    return locationGPS;
                } else {
                    return locationNetwork;
                }
            } else if (locationGPS != null) {
                return locationGPS;
            } else if (locationNetwork != null) {
                return locationNetwork;
            } else {
                return null;
            }
        } catch (SecurityException e) {
            e.printStackTrace();
            return null;
        }
    }


}
